﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AndroidPushNotifications
{
    public class PushDC
    {
        public System.Data.DataSet DS { get; set; }
    }
}